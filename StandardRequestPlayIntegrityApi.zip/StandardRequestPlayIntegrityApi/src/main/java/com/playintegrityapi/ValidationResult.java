package com.playintegrityapi;

import java.util.HashMap;
import java.util.Map;

public class ValidationResult {
    private boolean isValid;
    private Map<String, String> details;
 

    public ValidationResult() {
        this.isValid = true;
        this.details = new HashMap<>();
    }

    public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean isValid) {
        this.isValid = isValid;
    }

    public Map<String, String> getDetails() {
        return details;
    }

    public void addDetail(String key, String value) {
        if ("FAILED".equals(value)) {
            this.isValid = false;
        }
        this.details.put(key, value);
    }
	public void setDetails(Map<String, String> details) {
		this.details = details;
	}
    
}
