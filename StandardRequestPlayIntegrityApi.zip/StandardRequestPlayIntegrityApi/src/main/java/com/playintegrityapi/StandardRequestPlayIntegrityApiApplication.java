package com.playintegrityapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StandardRequestPlayIntegrityApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StandardRequestPlayIntegrityApiApplication.class, args);
	}

}
