package com.playintegrityapi.service;


public class RequestDto {
	
	private String integrityToken;
	private String expectedRequestHash;
    private String expectedPackageName;


	public String getIntegrityToken() {
		return integrityToken;
	}

	public void setIntegrityToken(String integrityToken) {
		this.integrityToken = integrityToken;
	}

	public String getExpectedRequestHash() {
		return expectedRequestHash;
	}

	public void setExpectedRequestHash(String expectedRequestHash) {
		this.expectedRequestHash = expectedRequestHash;
	}

	public String getExpectedPackageName() {
		return expectedPackageName;
	}

	public void setExpectedPackageName(String expectedPackageName) {
		this.expectedPackageName = expectedPackageName;
	}

}
