package com.playintegrityapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StandardRequestPlayIntegrityApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
